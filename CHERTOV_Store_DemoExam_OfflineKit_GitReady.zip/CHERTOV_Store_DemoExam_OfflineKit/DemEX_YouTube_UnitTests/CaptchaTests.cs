using System.Linq;
using DemEX.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DemEX.Tests
{
    [TestClass]
    public class CaptchaTests
    {
        [TestMethod]
        public void GeneratedCaptcha_ReturnsNonEmptyString()
        {
            string result = Captcha.GeneratedCaptcha();

            Assert.IsNotNull(result);
            Assert.IsFalse(string.IsNullOrWhiteSpace(result));
        }

        [TestMethod]
        public void GeneratedCaptcha_LengthIsBetweenSixAndNine()
        {
            string result = Captcha.GeneratedCaptcha();

            Assert.IsTrue(
                result.Length >= 6 && result.Length <= 9,
                "Длина капчи должна составлять от 6 до 9 символов."
            );
        }

        [TestMethod]
        public void GeneratedCaptcha_ContainsOnlyLettersAndDigits()
        {
            string result = Captcha.GeneratedCaptcha();

            Assert.IsTrue(
                result.All(character => char.IsLower(character) || char.IsDigit(character)),
                "Капча должна содержать только строчные буквы и цифры."
            );
        }
    }
}
