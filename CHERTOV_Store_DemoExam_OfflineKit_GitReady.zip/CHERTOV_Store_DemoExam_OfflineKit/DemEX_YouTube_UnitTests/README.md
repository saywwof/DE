# Unit-тесты по ролику YouTube для DemEX

1. Открыть `DemEX.sln`.
2. Добавить проект `Unit Test Project (.NET Framework)`.
3. Назвать его `DemEX.Tests`.
4. Framework выбрать такой же, как у основного проекта.
5. В `DemEX.Tests` добавить ссылку на проект `DemEX`.
6. Вставить содержимое `CaptchaTests.cs`.
7. Открыть `Test Explorer`.
8. Нажать `Run All`.
9. Сделать скриншот зелёных тестов.
