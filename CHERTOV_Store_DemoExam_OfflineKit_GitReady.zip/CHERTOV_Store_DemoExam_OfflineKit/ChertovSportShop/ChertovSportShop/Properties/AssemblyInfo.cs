using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ChertovSportShop")]
[assembly: AssemblyDescription("DemoExam WPF practice project")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("NPC")]
[assembly: AssemblyProduct("ChertovSportShop")]
[assembly: AssemblyCopyright("Copyright 2026")]
[assembly: ComVisible(false)]
[assembly: Guid("2D4D89A5-27DE-4BBA-8A5B-2C71916A2F11")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
