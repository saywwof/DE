using System;
using System.Windows;
using ChertovSportShop.Data;
using ChertovSportShop.Models;

namespace ChertovSportShop
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var session = Database.Authenticate(LoginTextBox.Text.Trim(), PasswordBox.Password);
                if (session == null)
                {
                    MessageBox.Show("Проверьте логин и пароль.", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                OpenProducts(session);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось подключиться к базе данных. Выполните SQL-скрипт и проверьте ConnectionString.\n\n" + ex.Message,
                    "Ошибка базы данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void GuestButton_Click(object sender, RoutedEventArgs e)
        {
            OpenProducts(new UserSession
            {
                UserId = 0,
                FullName = "Гость",
                RoleName = "Гость"
            });
        }

        private void OpenProducts(UserSession session)
        {
            var window = new ProductWindow(session);
            window.Show();
            Close();
        }
    }
}
