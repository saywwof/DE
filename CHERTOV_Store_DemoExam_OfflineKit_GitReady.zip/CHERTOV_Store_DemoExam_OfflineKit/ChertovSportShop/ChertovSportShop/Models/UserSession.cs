namespace ChertovSportShop.Models
{
    public class UserSession
    {
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string RoleName { get; set; }

        public bool IsAdmin => RoleName == "Администратор";
        public bool IsManager => RoleName == "Менеджер";
        public bool CanSearch => IsAdmin || IsManager;
    }
}
