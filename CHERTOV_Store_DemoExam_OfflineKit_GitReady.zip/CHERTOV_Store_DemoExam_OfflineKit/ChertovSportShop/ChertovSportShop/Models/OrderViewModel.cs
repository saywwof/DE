namespace ChertovSportShop.Models
{
    public class OrderViewModel
    {
        public int OrderId { get; set; }
        public string StatusName { get; set; }
        public string PickupAddress { get; set; }
        public string OrderDate { get; set; }
        public string DeliveryDate { get; set; }
        public string ProductArticles { get; set; }
    }
}
