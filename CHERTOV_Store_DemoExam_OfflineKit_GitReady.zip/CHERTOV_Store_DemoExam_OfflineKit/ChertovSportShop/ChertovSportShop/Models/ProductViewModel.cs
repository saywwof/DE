using ChertovSportShop.Services;

namespace ChertovSportShop.Models
{
    public class ProductViewModel
    {
        public int ProductId { get; set; }
        public string Article { get; set; }
        public string Title { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
        public int ManufacturerId { get; set; }
        public string ManufacturerName { get; set; }
        public int SupplierId { get; set; }
        public string SupplierName { get; set; }
        public int UnitId { get; set; }
        public string UnitName { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public int DiscountPercent { get; set; }
        public string ImagePath { get; set; }

        public decimal FinalPrice => PriceCalculator.CalculateFinalPrice(Price, DiscountPercent);

        public string PriceText => DiscountPercent > 0
            ? $"{Price:0.00} -> {FinalPrice:0.00} руб."
            : $"{Price:0.00} руб.";

        public string ProductBackground
        {
            get
            {
                if (Quantity == 0) return "#ADD8E6";
                if (DiscountPercent > 15) return "#2E8B57";
                return "White";
            }
        }
    }
}
