using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ChertovSportShop.Data;
using ChertovSportShop.Models;

namespace ChertovSportShop
{
    public partial class ProductWindow : Window
    {
        private readonly UserSession _session;
        private List<ProductViewModel> _products = new List<ProductViewModel>();

        public ProductWindow(UserSession session)
        {
            InitializeComponent();
            _session = session;
            UserTextBlock.Text = $"{session.FullName} ({session.RoleName})";
            ConfigureAccess();
            LoadSuppliers();
            LoadProducts();
        }

        private void ConfigureAccess()
        {
            FilterPanel.Visibility = _session.CanSearch ? Visibility.Visible : Visibility.Collapsed;
            AddButton.Visibility = _session.IsAdmin ? Visibility.Visible : Visibility.Collapsed;
            EditButton.Visibility = _session.IsAdmin ? Visibility.Visible : Visibility.Collapsed;
            DeleteButton.Visibility = _session.IsAdmin ? Visibility.Visible : Visibility.Collapsed;
        }

        private void LoadSuppliers()
        {
            try
            {
                SupplierComboBox.Items.Clear();
                SupplierComboBox.Items.Add(new LookupItem { Id = 0, Name = "Все поставщики" });
                foreach (var item in Database.GetLookup("Suppliers", "SupplierId", "SupplierName"))
                    SupplierComboBox.Items.Add(item);
                SupplierComboBox.SelectedIndex = 0;
            }
            catch
            {
                // Если база еще не создана, ошибка будет показана при загрузке товаров.
            }
        }

        private void LoadProducts()
        {
            try
            {
                _products = Database.GetProducts();
                ApplyFilters();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить товары. Проверьте базу ChertovSportShop.\n\n" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApplyFilters()
        {
            IEnumerable<ProductViewModel> result = _products;

            if (_session.CanSearch)
            {
                string search = SearchTextBox.Text.Trim().ToLower();
                if (!string.IsNullOrEmpty(search))
                {
                    result = result.Where(p =>
                        p.Article.ToLower().Contains(search) ||
                        p.Title.ToLower().Contains(search) ||
                        p.Description.ToLower().Contains(search) ||
                        p.CategoryName.ToLower().Contains(search) ||
                        p.ManufacturerName.ToLower().Contains(search) ||
                        p.SupplierName.ToLower().Contains(search));
                }

                if (SupplierComboBox.SelectedItem is LookupItem supplier && supplier.Id != 0)
                    result = result.Where(p => p.SupplierId == supplier.Id);

                var sortText = (SortComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
                if (sortText == "Количество по возрастанию")
                    result = result.OrderBy(p => p.Quantity);
                else if (sortText == "Количество по убыванию")
                    result = result.OrderByDescending(p => p.Quantity);
            }

            ProductsListView.ItemsSource = result.ToList();
        }

        private ProductViewModel SelectedProduct => ProductsListView.SelectedItem as ProductViewModel;

        private void FilterChanged(object sender, RoutedEventArgs e)
        {
            ApplyFilters();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadProducts();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            OpenEditWindow(new ProductViewModel());
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedProduct == null)
            {
                MessageBox.Show("Выберите товар для редактирования.", "Подсказка", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            OpenEditWindow(SelectedProduct);
        }

        private void ProductsListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (_session.IsAdmin && SelectedProduct != null)
                OpenEditWindow(SelectedProduct);
        }

        private void OpenEditWindow(ProductViewModel product)
        {
            var window = new ProductEditWindow(product);
            if (window.ShowDialog() == true)
                LoadProducts();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedProduct == null)
            {
                MessageBox.Show("Выберите товар для удаления.", "Подсказка", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                if (Database.ProductHasOrders(SelectedProduct.ProductId))
                {
                    MessageBox.Show("Этот товар присутствует в заказе. Удаление запрещено.", "Удаление невозможно", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (MessageBox.Show("Точно удалить выбранный товар?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    Database.DeleteProduct(SelectedProduct.ProductId);
                    LoadProducts();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления товара.\n" + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OrdersButton_Click(object sender, RoutedEventArgs e)
        {
            if (!(_session.IsAdmin || _session.IsManager))
            {
                MessageBox.Show("Заказы доступны только менеджеру и администратору.", "Доступ запрещен", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var window = new OrderWindow(_session);
            window.ShowDialog();
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            Close();
        }
    }
}
