using System.Windows;

namespace ChertovSportShop
{
    public partial class App : Application
    {
    }
}
