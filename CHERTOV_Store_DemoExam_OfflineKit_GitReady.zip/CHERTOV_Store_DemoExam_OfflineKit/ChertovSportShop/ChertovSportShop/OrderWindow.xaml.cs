using System;
using System.Windows;
using ChertovSportShop.Data;
using ChertovSportShop.Models;

namespace ChertovSportShop
{
    public partial class OrderWindow : Window
    {
        private readonly UserSession _session;

        public OrderWindow(UserSession session)
        {
            InitializeComponent();
            _session = session;
            LoadOrders();
        }

        private void LoadOrders()
        {
            try
            {
                OrdersDataGrid.ItemsSource = Database.GetOrders();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить заказы.\n" + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadOrders();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
