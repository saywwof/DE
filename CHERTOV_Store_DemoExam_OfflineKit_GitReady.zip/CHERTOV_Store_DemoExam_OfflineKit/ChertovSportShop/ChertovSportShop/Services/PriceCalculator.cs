using System;

namespace ChertovSportShop.Services
{
    public static class PriceCalculator
    {
        public static decimal CalculateFinalPrice(decimal price, int discountPercent)
        {
            if (price < 0)
                throw new ArgumentException("Цена не может быть отрицательной.");

            if (discountPercent < 0 || discountPercent > 100)
                throw new ArgumentException("Скидка должна быть от 0 до 100 процентов.");

            return price * (100 - discountPercent) / 100;
        }
    }
}
