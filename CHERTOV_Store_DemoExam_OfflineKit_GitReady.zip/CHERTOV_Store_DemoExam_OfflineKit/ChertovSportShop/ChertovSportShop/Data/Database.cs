using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using ChertovSportShop.Models;

namespace ChertovSportShop.Data
{
    public static class Database
    {
        // Если на компьютере другой SQL Server, поменяй эту строку.
        private const string ConnectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ChertovSportShop;Integrated Security=True;MultipleActiveResultSets=True";

        private static SqlConnection CreateConnection()
        {
            return new SqlConnection(ConnectionString);
        }

        public static UserSession Authenticate(string login, string password)
        {
            using (var connection = CreateConnection())
            {
                connection.Open();
                var command = new SqlCommand(@"
                    SELECT TOP 1 u.UserId, u.LastName, u.FirstName, u.MiddleName, r.RoleName
                    FROM dbo.Users u
                    JOIN dbo.Roles r ON r.RoleId = u.RoleId
                    WHERE u.Login = @login AND u.Password = @password", connection);

                command.Parameters.AddWithValue("@login", login);
                command.Parameters.AddWithValue("@password", password);

                using (var reader = command.ExecuteReader())
                {
                    if (!reader.Read()) return null;

                    return new UserSession
                    {
                        UserId = Convert.ToInt32(reader["UserId"]),
                        FullName = $"{reader["LastName"]} {reader["FirstName"]} {reader["MiddleName"]}".Trim(),
                        RoleName = reader["RoleName"].ToString()
                    };
                }
            }
        }

        public static List<ProductViewModel> GetProducts()
        {
            var products = new List<ProductViewModel>();
            using (var connection = CreateConnection())
            {
                connection.Open();
                var command = new SqlCommand(@"
                    SELECT p.ProductId, p.Article, p.Title, p.CategoryId, c.CategoryName,
                           p.Description, p.ManufacturerId, m.ManufacturerName,
                           p.SupplierId, s.SupplierName, p.UnitId, u.UnitName,
                           p.Price, p.Quantity, p.DiscountPercent, p.ImagePath
                    FROM dbo.Products p
                    JOIN dbo.Categories c ON c.CategoryId = p.CategoryId
                    JOIN dbo.Manufacturers m ON m.ManufacturerId = p.ManufacturerId
                    JOIN dbo.Suppliers s ON s.SupplierId = p.SupplierId
                    JOIN dbo.Units u ON u.UnitId = p.UnitId
                    ORDER BY p.ProductId", connection);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(new ProductViewModel
                        {
                            ProductId = Convert.ToInt32(reader["ProductId"]),
                            Article = reader["Article"].ToString(),
                            Title = reader["Title"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            CategoryName = reader["CategoryName"].ToString(),
                            Description = reader["Description"].ToString(),
                            ManufacturerId = Convert.ToInt32(reader["ManufacturerId"]),
                            ManufacturerName = reader["ManufacturerName"].ToString(),
                            SupplierId = Convert.ToInt32(reader["SupplierId"]),
                            SupplierName = reader["SupplierName"].ToString(),
                            UnitId = Convert.ToInt32(reader["UnitId"]),
                            UnitName = reader["UnitName"].ToString(),
                            Price = Convert.ToDecimal(reader["Price"]),
                            Quantity = Convert.ToInt32(reader["Quantity"]),
                            DiscountPercent = Convert.ToInt32(reader["DiscountPercent"]),
                            ImagePath = reader["ImagePath"].ToString()
                        });
                    }
                }
            }
            return products;
        }

        public static List<LookupItem> GetLookup(string tableName, string idColumn, string nameColumn)
        {
            var items = new List<LookupItem>();
            using (var connection = CreateConnection())
            {
                connection.Open();
                var command = new SqlCommand($"SELECT {idColumn}, {nameColumn} FROM dbo.{tableName} ORDER BY {nameColumn}", connection);
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        items.Add(new LookupItem
                        {
                            Id = Convert.ToInt32(reader[idColumn]),
                            Name = reader[nameColumn].ToString()
                        });
                    }
                }
            }
            return items;
        }

        public static void SaveProduct(ProductViewModel product)
        {
            using (var connection = CreateConnection())
            {
                connection.Open();
                SqlCommand command;

                if (product.ProductId == 0)
                {
                    command = new SqlCommand(@"
                        INSERT INTO dbo.Products (Article, Title, CategoryId, Description, ManufacturerId, SupplierId, UnitId, Price, Quantity, DiscountPercent, ImagePath)
                        VALUES (@Article, @Title, @CategoryId, @Description, @ManufacturerId, @SupplierId, @UnitId, @Price, @Quantity, @DiscountPercent, @ImagePath)", connection);
                }
                else
                {
                    command = new SqlCommand(@"
                        UPDATE dbo.Products
                        SET Article=@Article, Title=@Title, CategoryId=@CategoryId, Description=@Description,
                            ManufacturerId=@ManufacturerId, SupplierId=@SupplierId, UnitId=@UnitId,
                            Price=@Price, Quantity=@Quantity, DiscountPercent=@DiscountPercent, ImagePath=@ImagePath
                        WHERE ProductId=@ProductId", connection);
                    command.Parameters.AddWithValue("@ProductId", product.ProductId);
                }

                command.Parameters.AddWithValue("@Article", product.Article);
                command.Parameters.AddWithValue("@Title", product.Title);
                command.Parameters.AddWithValue("@CategoryId", product.CategoryId);
                command.Parameters.AddWithValue("@Description", (object)product.Description ?? DBNull.Value);
                command.Parameters.AddWithValue("@ManufacturerId", product.ManufacturerId);
                command.Parameters.AddWithValue("@SupplierId", product.SupplierId);
                command.Parameters.AddWithValue("@UnitId", product.UnitId);
                command.Parameters.AddWithValue("@Price", product.Price);
                command.Parameters.AddWithValue("@Quantity", product.Quantity);
                command.Parameters.AddWithValue("@DiscountPercent", product.DiscountPercent);
                command.Parameters.AddWithValue("@ImagePath", (object)product.ImagePath ?? DBNull.Value);
                command.ExecuteNonQuery();
            }
        }

        public static bool ProductHasOrders(int productId)
        {
            using (var connection = CreateConnection())
            {
                connection.Open();
                var command = new SqlCommand("SELECT COUNT(*) FROM dbo.OrderProducts WHERE ProductId=@ProductId", connection);
                command.Parameters.AddWithValue("@ProductId", productId);
                return Convert.ToInt32(command.ExecuteScalar()) > 0;
            }
        }

        public static void DeleteProduct(int productId)
        {
            using (var connection = CreateConnection())
            {
                connection.Open();
                var command = new SqlCommand("DELETE FROM dbo.Products WHERE ProductId=@ProductId", connection);
                command.Parameters.AddWithValue("@ProductId", productId);
                command.ExecuteNonQuery();
            }
        }

        public static List<OrderViewModel> GetOrders()
        {
            var orders = new List<OrderViewModel>();
            using (var connection = CreateConnection())
            {
                connection.Open();
                var command = new SqlCommand(@"
                    SELECT o.OrderId, os.StatusName, pp.Address, o.OrderDate, o.DeliveryDate,
                           STUFF((SELECT ', ' + p.Article
                                  FROM dbo.OrderProducts op
                                  JOIN dbo.Products p ON p.ProductId = op.ProductId
                                  WHERE op.OrderId = o.OrderId
                                  FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 2, '') AS Articles
                    FROM dbo.Orders o
                    JOIN dbo.OrderStatuses os ON os.StatusId = o.StatusId
                    JOIN dbo.PickupPoints pp ON pp.PickupPointId = o.PickupPointId
                    ORDER BY o.OrderId", connection);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        orders.Add(new OrderViewModel
                        {
                            OrderId = Convert.ToInt32(reader["OrderId"]),
                            StatusName = reader["StatusName"].ToString(),
                            PickupAddress = reader["Address"].ToString(),
                            OrderDate = Convert.ToDateTime(reader["OrderDate"]).ToShortDateString(),
                            DeliveryDate = reader["DeliveryDate"] == DBNull.Value ? "" : Convert.ToDateTime(reader["DeliveryDate"]).ToShortDateString(),
                            ProductArticles = reader["Articles"].ToString()
                        });
                    }
                }
            }
            return orders;
        }
    }
}
