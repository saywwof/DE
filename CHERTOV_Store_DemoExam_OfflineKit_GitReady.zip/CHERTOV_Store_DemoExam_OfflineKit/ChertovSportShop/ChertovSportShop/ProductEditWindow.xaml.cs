using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using ChertovSportShop.Data;
using ChertovSportShop.Models;

namespace ChertovSportShop
{
    public partial class ProductEditWindow : Window
    {
        private readonly ProductViewModel _product;

        public ProductEditWindow(ProductViewModel product)
        {
            InitializeComponent();
            _product = product;
            LoadLookups();
            FillFields();
        }

        private void LoadLookups()
        {
            CategoryComboBox.ItemsSource = Database.GetLookup("Categories", "CategoryId", "CategoryName");
            ManufacturerComboBox.ItemsSource = Database.GetLookup("Manufacturers", "ManufacturerId", "ManufacturerName");
            SupplierComboBox.ItemsSource = Database.GetLookup("Suppliers", "SupplierId", "SupplierName");
            UnitComboBox.ItemsSource = Database.GetLookup("Units", "UnitId", "UnitName");
        }

        private void FillFields()
        {
            IdTextBox.Text = _product.ProductId == 0 ? "Новый" : _product.ProductId.ToString();
            ArticleTextBox.Text = _product.Article;
            TitleTextBox.Text = _product.Title;
            DescriptionTextBox.Text = _product.Description;
            PriceTextBox.Text = _product.Price == 0 ? "" : _product.Price.ToString(CultureInfo.InvariantCulture);
            QuantityTextBox.Text = _product.Quantity.ToString();
            DiscountTextBox.Text = _product.DiscountPercent.ToString();
            SelectById(CategoryComboBox, _product.CategoryId);
            SelectById(ManufacturerComboBox, _product.ManufacturerId);
            SelectById(SupplierComboBox, _product.SupplierId);
            SelectById(UnitComboBox, _product.UnitId);
        }

        private void SelectById(ComboBox comboBox, int id)
        {
            foreach (LookupItem item in comboBox.Items)
            {
                if (item.Id == id)
                {
                    comboBox.SelectedItem = item;
                    return;
                }
            }

            if (comboBox.Items.Count > 0)
                comboBox.SelectedIndex = 0;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(ArticleTextBox.Text) || string.IsNullOrWhiteSpace(TitleTextBox.Text))
                {
                    MessageBox.Show("Заполните артикул и название товара.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (!decimal.TryParse(PriceTextBox.Text.Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal price) || price < 0)
                {
                    MessageBox.Show("Цена должна быть числом и не может быть отрицательной.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (!int.TryParse(QuantityTextBox.Text, out int quantity) || quantity < 0)
                {
                    MessageBox.Show("Количество должно быть целым числом и не может быть отрицательным.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (!int.TryParse(DiscountTextBox.Text, out int discount) || discount < 0 || discount > 100)
                {
                    MessageBox.Show("Скидка должна быть от 0 до 100.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                _product.Article = ArticleTextBox.Text.Trim();
                _product.Title = TitleTextBox.Text.Trim();
                _product.Description = DescriptionTextBox.Text.Trim();
                _product.CategoryId = ((LookupItem)CategoryComboBox.SelectedItem).Id;
                _product.ManufacturerId = ((LookupItem)ManufacturerComboBox.SelectedItem).Id;
                _product.SupplierId = ((LookupItem)SupplierComboBox.SelectedItem).Id;
                _product.UnitId = ((LookupItem)UnitComboBox.SelectedItem).Id;
                _product.Price = price;
                _product.Quantity = quantity;
                _product.DiscountPercent = discount;

                Database.SaveProduct(_product);
                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить товар.\n" + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
