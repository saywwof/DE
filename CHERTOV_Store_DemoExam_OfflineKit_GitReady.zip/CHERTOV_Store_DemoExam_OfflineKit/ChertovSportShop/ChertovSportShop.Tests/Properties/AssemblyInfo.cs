using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ChertovSportShop.Tests")]
[assembly: AssemblyDescription("Unit tests for demo exam practice")]
[assembly: AssemblyCompany("NPC")]
[assembly: AssemblyProduct("ChertovSportShop.Tests")]
[assembly: ComVisible(false)]
[assembly: Guid("98476EA2-CE43-4C3D-9C9C-87E1D82EC85B")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
