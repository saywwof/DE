using System;
using ChertovSportShop.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ChertovSportShop.Tests
{
    [TestClass]
    public class PriceCalculatorTests
    {
        [TestMethod]
        public void CalculateFinalPrice_Discount10_Returns900()
        {
            decimal result = PriceCalculator.CalculateFinalPrice(1000m, 10);
            Assert.AreEqual(900m, result);
        }

        [TestMethod]
        public void CalculateFinalPrice_Discount0_ReturnsOriginalPrice()
        {
            decimal result = PriceCalculator.CalculateFinalPrice(1590m, 0);
            Assert.AreEqual(1590m, result);
        }

        [TestMethod]
        public void CalculateFinalPrice_NegativePrice_ThrowsException()
        {
            Assert.ThrowsException<ArgumentException>(() => PriceCalculator.CalculateFinalPrice(-100m, 10));
        }

        [TestMethod]
        public void CalculateFinalPrice_DiscountMoreThan100_ThrowsException()
        {
            Assert.ThrowsException<ArgumentException>(() => PriceCalculator.CalculateFinalPrice(1000m, 101));
        }
    }
}
