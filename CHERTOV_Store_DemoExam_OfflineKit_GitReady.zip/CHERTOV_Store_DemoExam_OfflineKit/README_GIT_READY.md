# CHERTOV Store DemoExam OfflineKit — Git Ready

Этот набор нужен для подготовки, репетиции и проверки среды. На экзамене используй только то, что разрешено площадкой и экспертами.

## Что открывать

1. SQL-скрипт базы:
   `SQL/03_Create_All.sql`

2. Проект Visual Studio:
   `ChertovSportShop/ChertovSportShop.sln`

3. Unit-тесты:
   `ChertovSportShop/ChertovSportShop.Tests/PriceCalculatorTests.cs`

4. Подробная инструкция:
   `DOC/manual_ChertovSportShop.pdf`

5. Шпаргалки для повторения:
   `Cheatsheets/`

## Быстрый запуск

1. Распаковать папку в `C:\DE\CHERTOV_Store_DemoExam_OfflineKit`.
2. Открыть SSMS.
3. Выполнить `SQL/03_Create_All.sql`.
4. Открыть `ChertovSportShop/ChertovSportShop.sln`.
5. Нажать `Build -> Rebuild Solution`.
6. Запустить проект.
7. Войти:
   - `admin / admin123`
   - `manager / manager123`
   - `client / client123`

## Что проверить

- Открывается ли `.sln`.
- Собирается ли решение.
- Запускается ли приложение.
- Подключается ли база.
- Работает ли список товаров.
- Работают ли поиск, фильтр, сортировка.
- Работает ли добавление товара.
- Запускаются ли unit-тесты.

