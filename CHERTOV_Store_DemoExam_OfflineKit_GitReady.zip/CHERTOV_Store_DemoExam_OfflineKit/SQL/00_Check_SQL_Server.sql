SELECT @@SERVERNAME AS ServerName;
SELECT @@VERSION AS SqlServerVersion;
GO

IF DB_ID('ChertovSportShop') IS NOT NULL
    SELECT 'ChertovSportShop database exists' AS Status;
ELSE
    SELECT 'ChertovSportShop database does not exist yet' AS Status;
GO
