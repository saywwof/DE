/*
  ChertovSportShop - создание базы и таблиц
  Предметная область: магазин спортивных товаров.
  СУБД: Microsoft SQL Server / LocalDB.
*/

IF DB_ID(N'ChertovSportShop') IS NULL
BEGIN
    CREATE DATABASE ChertovSportShop;
END
GO

USE ChertovSportShop;
GO

IF OBJECT_ID(N'dbo.OrderProducts', N'U') IS NOT NULL DROP TABLE dbo.OrderProducts;
IF OBJECT_ID(N'dbo.Orders', N'U') IS NOT NULL DROP TABLE dbo.Orders;
IF OBJECT_ID(N'dbo.Products', N'U') IS NOT NULL DROP TABLE dbo.Products;
IF OBJECT_ID(N'dbo.Users', N'U') IS NOT NULL DROP TABLE dbo.Users;
IF OBJECT_ID(N'dbo.OrderStatuses', N'U') IS NOT NULL DROP TABLE dbo.OrderStatuses;
IF OBJECT_ID(N'dbo.PickupPoints', N'U') IS NOT NULL DROP TABLE dbo.PickupPoints;
IF OBJECT_ID(N'dbo.Roles', N'U') IS NOT NULL DROP TABLE dbo.Roles;
IF OBJECT_ID(N'dbo.Categories', N'U') IS NOT NULL DROP TABLE dbo.Categories;
IF OBJECT_ID(N'dbo.Manufacturers', N'U') IS NOT NULL DROP TABLE dbo.Manufacturers;
IF OBJECT_ID(N'dbo.Suppliers', N'U') IS NOT NULL DROP TABLE dbo.Suppliers;
IF OBJECT_ID(N'dbo.Units', N'U') IS NOT NULL DROP TABLE dbo.Units;
GO

CREATE TABLE dbo.Roles (
    RoleId INT IDENTITY(1,1) PRIMARY KEY,
    RoleName NVARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE dbo.Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    RoleId INT NOT NULL,
    Login NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(100) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    FirstName NVARCHAR(50) NOT NULL,
    MiddleName NVARCHAR(50) NULL,
    CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleId) REFERENCES dbo.Roles(RoleId)
);

CREATE TABLE dbo.Categories (
    CategoryId INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE dbo.Manufacturers (
    ManufacturerId INT IDENTITY(1,1) PRIMARY KEY,
    ManufacturerName NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE dbo.Suppliers (
    SupplierId INT IDENTITY(1,1) PRIMARY KEY,
    SupplierName NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE dbo.Units (
    UnitId INT IDENTITY(1,1) PRIMARY KEY,
    UnitName NVARCHAR(30) NOT NULL UNIQUE
);

CREATE TABLE dbo.Products (
    ProductId INT IDENTITY(1,1) PRIMARY KEY,
    Article NVARCHAR(50) NOT NULL UNIQUE,
    Title NVARCHAR(150) NOT NULL,
    CategoryId INT NOT NULL,
    Description NVARCHAR(500) NULL,
    ManufacturerId INT NOT NULL,
    SupplierId INT NOT NULL,
    UnitId INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    Quantity INT NOT NULL,
    DiscountPercent INT NOT NULL DEFAULT 0,
    ImagePath NVARCHAR(255) NULL,
    CONSTRAINT FK_Products_Categories FOREIGN KEY (CategoryId) REFERENCES dbo.Categories(CategoryId),
    CONSTRAINT FK_Products_Manufacturers FOREIGN KEY (ManufacturerId) REFERENCES dbo.Manufacturers(ManufacturerId),
    CONSTRAINT FK_Products_Suppliers FOREIGN KEY (SupplierId) REFERENCES dbo.Suppliers(SupplierId),
    CONSTRAINT FK_Products_Units FOREIGN KEY (UnitId) REFERENCES dbo.Units(UnitId),
    CONSTRAINT CK_Products_Price CHECK (Price >= 0),
    CONSTRAINT CK_Products_Quantity CHECK (Quantity >= 0),
    CONSTRAINT CK_Products_Discount CHECK (DiscountPercent BETWEEN 0 AND 100)
);

CREATE TABLE dbo.PickupPoints (
    PickupPointId INT IDENTITY(1,1) PRIMARY KEY,
    Address NVARCHAR(250) NOT NULL
);

CREATE TABLE dbo.OrderStatuses (
    StatusId INT IDENTITY(1,1) PRIMARY KEY,
    StatusName NVARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE dbo.Orders (
    OrderId INT IDENTITY(1,1) PRIMARY KEY,
    StatusId INT NOT NULL,
    PickupPointId INT NOT NULL,
    OrderDate DATE NOT NULL,
    DeliveryDate DATE NULL,
    CONSTRAINT FK_Orders_Statuses FOREIGN KEY (StatusId) REFERENCES dbo.OrderStatuses(StatusId),
    CONSTRAINT FK_Orders_PickupPoints FOREIGN KEY (PickupPointId) REFERENCES dbo.PickupPoints(PickupPointId)
);

CREATE TABLE dbo.OrderProducts (
    OrderId INT NOT NULL,
    ProductId INT NOT NULL,
    Count INT NOT NULL,
    PRIMARY KEY (OrderId, ProductId),
    CONSTRAINT FK_OrderProducts_Orders FOREIGN KEY (OrderId) REFERENCES dbo.Orders(OrderId) ON DELETE CASCADE,
    CONSTRAINT FK_OrderProducts_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    CONSTRAINT CK_OrderProducts_Count CHECK (Count > 0)
);
GO
