USE ChertovSportShop;
GO

-- Проверка пользователей и ролей
SELECT u.Login, u.LastName, u.FirstName, u.MiddleName, r.RoleName
FROM dbo.Users u
JOIN dbo.Roles r ON r.RoleId = u.RoleId;

-- Товары с расшифровкой справочников
SELECT p.ProductId, p.Article, p.Title, c.CategoryName, m.ManufacturerName, s.SupplierName,
       u.UnitName, p.Price, p.Quantity, p.DiscountPercent,
       p.Price * (100 - p.DiscountPercent) / 100 AS FinalPrice
FROM dbo.Products p
JOIN dbo.Categories c ON c.CategoryId = p.CategoryId
JOIN dbo.Manufacturers m ON m.ManufacturerId = p.ManufacturerId
JOIN dbo.Suppliers s ON s.SupplierId = p.SupplierId
JOIN dbo.Units u ON u.UnitId = p.UnitId;

-- Поиск товара по тексту
SELECT * FROM dbo.Products
WHERE Title LIKE N'%рюкзак%' OR Description LIKE N'%рюкзак%' OR Article LIKE N'%рюкзак%';

-- Товары, которые нельзя удалить, потому что они есть в заказах
SELECT DISTINCT p.ProductId, p.Title
FROM dbo.Products p
JOIN dbo.OrderProducts op ON op.ProductId = p.ProductId;
