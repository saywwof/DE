/*
  ChertovSportShop - создание базы и таблиц
  Предметная область: магазин спортивных товаров.
  СУБД: Microsoft SQL Server / LocalDB.
*/

IF DB_ID(N'ChertovSportShop') IS NULL
BEGIN
    CREATE DATABASE ChertovSportShop;
END
GO

USE ChertovSportShop;
GO

IF OBJECT_ID(N'dbo.OrderProducts', N'U') IS NOT NULL DROP TABLE dbo.OrderProducts;
IF OBJECT_ID(N'dbo.Orders', N'U') IS NOT NULL DROP TABLE dbo.Orders;
IF OBJECT_ID(N'dbo.Products', N'U') IS NOT NULL DROP TABLE dbo.Products;
IF OBJECT_ID(N'dbo.Users', N'U') IS NOT NULL DROP TABLE dbo.Users;
IF OBJECT_ID(N'dbo.OrderStatuses', N'U') IS NOT NULL DROP TABLE dbo.OrderStatuses;
IF OBJECT_ID(N'dbo.PickupPoints', N'U') IS NOT NULL DROP TABLE dbo.PickupPoints;
IF OBJECT_ID(N'dbo.Roles', N'U') IS NOT NULL DROP TABLE dbo.Roles;
IF OBJECT_ID(N'dbo.Categories', N'U') IS NOT NULL DROP TABLE dbo.Categories;
IF OBJECT_ID(N'dbo.Manufacturers', N'U') IS NOT NULL DROP TABLE dbo.Manufacturers;
IF OBJECT_ID(N'dbo.Suppliers', N'U') IS NOT NULL DROP TABLE dbo.Suppliers;
IF OBJECT_ID(N'dbo.Units', N'U') IS NOT NULL DROP TABLE dbo.Units;
GO

CREATE TABLE dbo.Roles (
    RoleId INT IDENTITY(1,1) PRIMARY KEY,
    RoleName NVARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE dbo.Users (
    UserId INT IDENTITY(1,1) PRIMARY KEY,
    RoleId INT NOT NULL,
    Login NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(100) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    FirstName NVARCHAR(50) NOT NULL,
    MiddleName NVARCHAR(50) NULL,
    CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleId) REFERENCES dbo.Roles(RoleId)
);

CREATE TABLE dbo.Categories (
    CategoryId INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE dbo.Manufacturers (
    ManufacturerId INT IDENTITY(1,1) PRIMARY KEY,
    ManufacturerName NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE dbo.Suppliers (
    SupplierId INT IDENTITY(1,1) PRIMARY KEY,
    SupplierName NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE dbo.Units (
    UnitId INT IDENTITY(1,1) PRIMARY KEY,
    UnitName NVARCHAR(30) NOT NULL UNIQUE
);

CREATE TABLE dbo.Products (
    ProductId INT IDENTITY(1,1) PRIMARY KEY,
    Article NVARCHAR(50) NOT NULL UNIQUE,
    Title NVARCHAR(150) NOT NULL,
    CategoryId INT NOT NULL,
    Description NVARCHAR(500) NULL,
    ManufacturerId INT NOT NULL,
    SupplierId INT NOT NULL,
    UnitId INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    Quantity INT NOT NULL,
    DiscountPercent INT NOT NULL DEFAULT 0,
    ImagePath NVARCHAR(255) NULL,
    CONSTRAINT FK_Products_Categories FOREIGN KEY (CategoryId) REFERENCES dbo.Categories(CategoryId),
    CONSTRAINT FK_Products_Manufacturers FOREIGN KEY (ManufacturerId) REFERENCES dbo.Manufacturers(ManufacturerId),
    CONSTRAINT FK_Products_Suppliers FOREIGN KEY (SupplierId) REFERENCES dbo.Suppliers(SupplierId),
    CONSTRAINT FK_Products_Units FOREIGN KEY (UnitId) REFERENCES dbo.Units(UnitId),
    CONSTRAINT CK_Products_Price CHECK (Price >= 0),
    CONSTRAINT CK_Products_Quantity CHECK (Quantity >= 0),
    CONSTRAINT CK_Products_Discount CHECK (DiscountPercent BETWEEN 0 AND 100)
);

CREATE TABLE dbo.PickupPoints (
    PickupPointId INT IDENTITY(1,1) PRIMARY KEY,
    Address NVARCHAR(250) NOT NULL
);

CREATE TABLE dbo.OrderStatuses (
    StatusId INT IDENTITY(1,1) PRIMARY KEY,
    StatusName NVARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE dbo.Orders (
    OrderId INT IDENTITY(1,1) PRIMARY KEY,
    StatusId INT NOT NULL,
    PickupPointId INT NOT NULL,
    OrderDate DATE NOT NULL,
    DeliveryDate DATE NULL,
    CONSTRAINT FK_Orders_Statuses FOREIGN KEY (StatusId) REFERENCES dbo.OrderStatuses(StatusId),
    CONSTRAINT FK_Orders_PickupPoints FOREIGN KEY (PickupPointId) REFERENCES dbo.PickupPoints(PickupPointId)
);

CREATE TABLE dbo.OrderProducts (
    OrderId INT NOT NULL,
    ProductId INT NOT NULL,
    Count INT NOT NULL,
    PRIMARY KEY (OrderId, ProductId),
    CONSTRAINT FK_OrderProducts_Orders FOREIGN KEY (OrderId) REFERENCES dbo.Orders(OrderId) ON DELETE CASCADE,
    CONSTRAINT FK_OrderProducts_Products FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId),
    CONSTRAINT CK_OrderProducts_Count CHECK (Count > 0)
);
GO
USE ChertovSportShop;
GO

INSERT INTO dbo.Roles (RoleName) VALUES
(N'Клиент'), (N'Менеджер'), (N'Администратор');

INSERT INTO dbo.Users (RoleId, Login, Password, LastName, FirstName, MiddleName) VALUES
(1, N'client', N'client123', N'Смирнов', N'Артем', N'Игоревич'),
(2, N'manager', N'manager123', N'Петрова', N'Мария', N'Олеговна'),
(3, N'admin', N'admin123', N'Чертов', N'Иван', N'Дмитриевич');

INSERT INTO dbo.Categories (CategoryName) VALUES
(N'Рюкзаки'), (N'Бутылки'), (N'Перчатки'), (N'Эспандеры'), (N'Футболки');

INSERT INTO dbo.Manufacturers (ManufacturerName) VALUES
(N'NordFit'), (N'UrbanRun'), (N'IronGrip'), (N'PeakLine');

INSERT INTO dbo.Suppliers (SupplierName) VALUES
(N'СибирьСпорт'), (N'АктивТрейд'), (N'ФитнесСклад');

INSERT INTO dbo.Units (UnitName) VALUES
(N'шт'), (N'пара');

INSERT INTO dbo.Products (Article, Title, CategoryId, Description, ManufacturerId, SupplierId, UnitId, Price, Quantity, DiscountPercent, ImagePath) VALUES
(N'RB-001', N'Городской спортивный рюкзак', 1, N'Рюкзак 25 литров для учебы и тренировок', 1, 1, 1, 2490.00, 12, 10, N'Images/backpack.png'),
(N'BT-101', N'Бутылка для воды 700 мл', 2, N'Пластиковая бутылка с мерной шкалой', 2, 2, 1, 590.00, 30, 0, N'Images/bottle.png'),
(N'GL-220', N'Перчатки для зала', 3, N'Перчатки с фиксацией кисти', 3, 3, 2, 1290.00, 7, 20, N'Images/gloves.png'),
(N'EX-310', N'Кистевой эспандер', 4, N'Металлический эспандер 40 кг', 3, 1, 1, 450.00, 0, 5, N'Images/expander.png'),
(N'TS-500', N'Футболка тренировочная', 5, N'Дышащая футболка для спорта', 4, 2, 1, 1590.00, 18, 0, N'Images/tshirt.png'),
(N'RB-015', N'Рюкзак тактический малый', 1, N'Прочный рюкзак с внешними креплениями', 4, 3, 1, 3190.00, 4, 18, N'Images/tactical.png');

INSERT INTO dbo.PickupPoints (Address) VALUES
(N'Новосибирск, ул. Российская, 3'),
(N'Искитим, ул. Советская, 12'),
(N'Бердск, ул. Ленина, 45');

INSERT INTO dbo.OrderStatuses (StatusName) VALUES
(N'Новый'), (N'Собирается'), (N'Готов к выдаче'), (N'Выдан');

INSERT INTO dbo.Orders (StatusId, PickupPointId, OrderDate, DeliveryDate) VALUES
(1, 1, '2026-06-01', '2026-06-04'),
(3, 2, '2026-06-02', '2026-06-05');

INSERT INTO dbo.OrderProducts (OrderId, ProductId, Count) VALUES
(1, 1, 1),
(1, 2, 2),
(2, 3, 1);
GO
