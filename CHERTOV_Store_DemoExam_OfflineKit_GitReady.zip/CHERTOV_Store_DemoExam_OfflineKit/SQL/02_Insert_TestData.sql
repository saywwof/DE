USE ChertovSportShop;
GO

INSERT INTO dbo.Roles (RoleName) VALUES
(N'Клиент'), (N'Менеджер'), (N'Администратор');

INSERT INTO dbo.Users (RoleId, Login, Password, LastName, FirstName, MiddleName) VALUES
(1, N'client', N'client123', N'Смирнов', N'Артем', N'Игоревич'),
(2, N'manager', N'manager123', N'Петрова', N'Мария', N'Олеговна'),
(3, N'admin', N'admin123', N'Чертов', N'Иван', N'Дмитриевич');

INSERT INTO dbo.Categories (CategoryName) VALUES
(N'Рюкзаки'), (N'Бутылки'), (N'Перчатки'), (N'Эспандеры'), (N'Футболки');

INSERT INTO dbo.Manufacturers (ManufacturerName) VALUES
(N'NordFit'), (N'UrbanRun'), (N'IronGrip'), (N'PeakLine');

INSERT INTO dbo.Suppliers (SupplierName) VALUES
(N'СибирьСпорт'), (N'АктивТрейд'), (N'ФитнесСклад');

INSERT INTO dbo.Units (UnitName) VALUES
(N'шт'), (N'пара');

INSERT INTO dbo.Products (Article, Title, CategoryId, Description, ManufacturerId, SupplierId, UnitId, Price, Quantity, DiscountPercent, ImagePath) VALUES
(N'RB-001', N'Городской спортивный рюкзак', 1, N'Рюкзак 25 литров для учебы и тренировок', 1, 1, 1, 2490.00, 12, 10, N'Images/backpack.png'),
(N'BT-101', N'Бутылка для воды 700 мл', 2, N'Пластиковая бутылка с мерной шкалой', 2, 2, 1, 590.00, 30, 0, N'Images/bottle.png'),
(N'GL-220', N'Перчатки для зала', 3, N'Перчатки с фиксацией кисти', 3, 3, 2, 1290.00, 7, 20, N'Images/gloves.png'),
(N'EX-310', N'Кистевой эспандер', 4, N'Металлический эспандер 40 кг', 3, 1, 1, 450.00, 0, 5, N'Images/expander.png'),
(N'TS-500', N'Футболка тренировочная', 5, N'Дышащая футболка для спорта', 4, 2, 1, 1590.00, 18, 0, N'Images/tshirt.png'),
(N'RB-015', N'Рюкзак тактический малый', 1, N'Прочный рюкзак с внешними креплениями', 4, 3, 1, 3190.00, 4, 18, N'Images/tactical.png');

INSERT INTO dbo.PickupPoints (Address) VALUES
(N'Новосибирск, ул. Российская, 3'),
(N'Искитим, ул. Советская, 12'),
(N'Бердск, ул. Ленина, 45');

INSERT INTO dbo.OrderStatuses (StatusName) VALUES
(N'Новый'), (N'Собирается'), (N'Готов к выдаче'), (N'Выдан');

INSERT INTO dbo.Orders (StatusId, PickupPointId, OrderDate, DeliveryDate) VALUES
(1, 1, '2026-06-01', '2026-06-04'),
(3, 2, '2026-06-02', '2026-06-05');

INSERT INTO dbo.OrderProducts (OrderId, ProductId, Count) VALUES
(1, 1, 1),
(1, 2, 2),
(2, 3, 1);
GO
