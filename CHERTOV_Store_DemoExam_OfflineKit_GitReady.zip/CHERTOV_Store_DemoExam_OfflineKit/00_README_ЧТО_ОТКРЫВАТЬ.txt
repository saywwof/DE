CHERTOV SPORT SHOP - офлайн-набор для подготовки к ДЭ 09.02.07

Что внутри:
1) SQL/03_Create_All.sql - один общий скрипт: создает базу ChertovSportShop и тестовые данные.
2) ChertovSportShop/ChertovSportShop.sln - готовый WPF-проект для Visual Studio.
3) ChertovSportShop/ChertovSportShop.Tests - проект unit-тестов MSTest.
4) DOC/manual_ChertovSportShop.docx - подробное пояснение: что где находится и как запускать.
5) ER/ER_diagram_ChertovSportShop.pdf - ER-диаграмма базы.
6) Cheatsheets/ - короткие шпаргалки по SQL, WPF, Git Bash и порядку работы.

Порядок запуска:
1. Открыть SQL Server Management Studio.
2. Выполнить SQL/03_Create_All.sql.
3. Открыть ChertovSportShop/ChertovSportShop.sln в Visual Studio.
4. Нажать Сборка -> Перестроить решение.
5. Запустить ChertovSportShop.
6. Логины для проверки:
   admin / admin123 - Администратор
   manager / manager123 - Менеджер
   client / client123 - Клиент
   guest - кнопка Войти как гость

Если база называется иначе или LocalDB не работает, открыть ChertovSportShop/Data/Database.cs и поменять ConnectionString.
