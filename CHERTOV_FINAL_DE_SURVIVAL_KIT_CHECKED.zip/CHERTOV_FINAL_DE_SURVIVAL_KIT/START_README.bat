@echo off
chcp 65001 > nul
type "00_ОТКРОЙ_СНАЧАЛА.txt"
pause
