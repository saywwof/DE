using System;

namespace SportShopExamApp.Utils
{
    public static class PriceCalculator
    {
        public static decimal ApplyDiscount(decimal price, int discountPercent)
        {
            if (price < 0) throw new ArgumentException("Цена не может быть отрицательной.");
            if (discountPercent < 0 || discountPercent > 100) throw new ArgumentException("Скидка должна быть от 0 до 100.");
            return Math.Round(price * (100 - discountPercent) / 100m, 2);
        }
    }
}
