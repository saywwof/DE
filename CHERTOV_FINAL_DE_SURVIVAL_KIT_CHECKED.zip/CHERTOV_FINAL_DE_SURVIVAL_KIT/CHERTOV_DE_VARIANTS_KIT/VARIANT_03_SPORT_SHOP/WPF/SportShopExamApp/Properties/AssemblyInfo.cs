using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SportShopExamApp")]
[assembly: AssemblyDescription("Demo exam template")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Chertov")]
[assembly: AssemblyProduct("SportShopExamApp")]
[assembly: AssemblyCopyright("Copyright")]
[assembly: ComVisible(false)]
[assembly: Guid("12345678-1234-1234-1234-123456789abc")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
