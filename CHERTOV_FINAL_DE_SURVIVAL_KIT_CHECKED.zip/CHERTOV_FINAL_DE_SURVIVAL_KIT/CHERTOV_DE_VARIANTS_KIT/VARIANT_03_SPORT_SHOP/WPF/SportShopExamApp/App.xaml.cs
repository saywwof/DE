using System.Windows;

namespace SportShopExamApp
{
    public partial class App : Application
    {
    }
}
