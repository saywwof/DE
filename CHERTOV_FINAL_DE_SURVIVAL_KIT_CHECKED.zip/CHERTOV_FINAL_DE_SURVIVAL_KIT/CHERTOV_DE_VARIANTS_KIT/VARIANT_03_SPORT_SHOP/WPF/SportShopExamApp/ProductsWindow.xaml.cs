using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using SportShopExamApp.Data;

namespace SportShopExamApp
{
    public partial class ProductsWindow : Window
    {
        private readonly string _roleName;
        private readonly string _fullName;

        public ProductsWindow(string roleName, string fullName)
        {
            InitializeComponent();
            _roleName = roleName;
            _fullName = fullName;
            UserText.Text = $"{_fullName} ({_roleName})";
            ConfigureRights();
            LoadSuppliers();
            LoadProducts();
        }

        private bool IsAdmin => _roleName == "Admin";
        private bool IsManager => _roleName == "Manager";

        private void ConfigureRights()
        {
            AddButton.Visibility = IsAdmin ? Visibility.Visible : Visibility.Collapsed;
            EditButton.Visibility = IsAdmin ? Visibility.Visible : Visibility.Collapsed;
            DeleteButton.Visibility = IsAdmin ? Visibility.Visible : Visibility.Collapsed;
            bool canWorkWithOrders = IsAdmin || IsManager;
            OrdersButton.Visibility = canWorkWithOrders ? Visibility.Visible : Visibility.Collapsed;
            SearchBox.IsEnabled = IsAdmin || IsManager;
            SupplierCombo.IsEnabled = IsAdmin || IsManager;
            SortCombo.IsEnabled = IsAdmin || IsManager;
        }

        private void LoadSuppliers()
        {
            var table = Database.GetTable("SELECT 0 AS Id, N'Все поставщики' AS Name UNION ALL SELECT Id, Name FROM Suppliers ORDER BY Name");
            SupplierCombo.ItemsSource = table.DefaultView;
            SupplierCombo.DisplayMemberPath = "Name";
            SupplierCombo.SelectedValuePath = "Id";
            SupplierCombo.SelectedIndex = 0;
        }

        private void LoadProducts()
        {
            try
            {
                string orderBy = "p.Id";
                if (SortCombo.SelectedIndex == 1) orderBy = "p.StockQuantity ASC";
                if (SortCombo.SelectedIndex == 2) orderBy = "p.StockQuantity DESC";

                int supplierId = 0;
                if (SupplierCombo.SelectedValue != null) int.TryParse(SupplierCombo.SelectedValue.ToString(), out supplierId);

                string search = SearchBox.Text.Trim();
                var table = Database.GetTable($@"
SELECT p.Id, p.Name, c.Name AS Category, p.Description, m.Name AS Manufacturer, s.Name AS Supplier,
       p.Price, u.Name AS Unit, p.StockQuantity, p.Discount,
       CAST(p.Price * (1 - p.Discount / 100.0) AS DECIMAL(10,2)) AS FinalPrice
FROM Products p
JOIN Categories c ON c.Id = p.CategoryId
JOIN Manufacturers m ON m.Id = p.ManufacturerId
JOIN Suppliers s ON s.Id = p.SupplierId
JOIN Units u ON u.Id = p.UnitId
WHERE (@Search = N'' OR p.Name LIKE @Like OR p.Description LIKE @Like OR c.Name LIKE @Like OR m.Name LIKE @Like OR s.Name LIKE @Like)
  AND (@SupplierId = 0 OR p.SupplierId = @SupplierId)
ORDER BY {orderBy}",
                    Database.Param("@Search", search),
                    Database.Param("@Like", "%" + search + "%"),
                    Database.Param("@SupplierId", supplierId));

                ProductsGrid.ItemsSource = table.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки списка.
" + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private int? SelectedProductId()
        {
            if (ProductsGrid.SelectedItem == null) return null;
            var row = (DataRowView)ProductsGrid.SelectedItem;
            return Convert.ToInt32(row["Id"]);
        }

        private void Filter_Changed(object sender, EventArgs e)
        {
            if (ProductsGrid != null) LoadProducts();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            new EditProductWindow(null).ShowDialog();
            LoadProducts();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            var id = SelectedProductId();
            if (id == null)
            {
                MessageBox.Show("Выберите запись для редактирования.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            new EditProductWindow(id.Value).ShowDialog();
            LoadProducts();
        }

        private void ProductsGrid_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (IsAdmin) Edit_Click(sender, e);
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var id = SelectedProductId();
            if (id == null)
            {
                MessageBox.Show("Выберите запись для удаления.", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            int inOrders = Convert.ToInt32(Database.GetScalar("SELECT COUNT(*) FROM OrderProducts WHERE ProductId=@Id", Database.Param("@Id", id.Value)));
            if (inOrders > 0)
            {
                MessageBox.Show("Нельзя удалить товар/услугу, потому что он уже используется в заказе.", "Удаление запрещено", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            Database.Execute("DELETE FROM Products WHERE Id=@Id", Database.Param("@Id", id.Value));
            LoadProducts();
        }

        private void Orders_Click(object sender, RoutedEventArgs e)
        {
            new OrdersWindow().ShowDialog();
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            Close();
        }
    }
}
