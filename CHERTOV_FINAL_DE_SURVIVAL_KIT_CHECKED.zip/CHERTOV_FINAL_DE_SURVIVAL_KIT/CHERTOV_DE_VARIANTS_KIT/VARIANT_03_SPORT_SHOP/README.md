# Магазин спортивных товаров

Открывать: `WPF/SportShopExamApp.sln`

SQL: `SQL/01_Create_Database.sql`

База данных: `SportShopExam`

Логины:

- admin / admin123
- manager / manager123
- client / client123

Смысл варианта: Магазин спортивных товаров. Можно использовать как тренировочную основу и быстро переделать названия под другую предметную область.
