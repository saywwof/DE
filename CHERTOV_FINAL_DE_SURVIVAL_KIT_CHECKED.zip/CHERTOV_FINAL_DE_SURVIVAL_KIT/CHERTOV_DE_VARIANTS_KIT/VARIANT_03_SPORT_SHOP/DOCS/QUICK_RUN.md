# Быстрый запуск

1. Открыть SQL Server Management Studio.
2. Подключиться к `(localdb)\MSSQLLocalDB`.
3. Открыть `SQL/01_Create_Database.sql`.
4. Нажать Execute.
5. Открыть Visual Studio.
6. Открыть `WPF/SportShopExamApp.sln`.
7. Сборка - Перестроить решение.
8. Запустить.
9. Войти `admin / admin123`.
10. Проверить список, поиск, фильтр, сортировку, добавление, редактирование, удаление.
11. Открыть Test Explorer - Запустить все.
