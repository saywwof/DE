# Git Bash - только нужный минимум

Открыть Git Bash в папке проекта или перейти командой:

```bash
cd /c/DE/CHERTOV_DE_VARIANTS_KIT/VARIANT_03_SPORT_SHOP/WPF/SportShopExamApp
```

Показать текущую папку:

```bash
pwd
```

Показать файлы:

```bash
ls
```

Создать локальный репозиторий:

```bash
git init
```

Проверить состояние:

```bash
git status
```

Добавить файлы:

```bash
git add .
```

Сохранить версию:

```bash
git commit -m "working version"
```

Проверить историю:

```bash
git log --oneline
```

Для подготовки дома можно залить в свой репозиторий:

```bash
git branch -M main
git remote add origin https://github.com/YOUR_LOGIN/YOUR_REPO.git
git push -u origin main
```

На проверке компьютеров в понедельник важнее не GitHub, а понять, есть ли Git Bash, открывается ли папка проекта и работает ли `git status`.
