# Автосервис

Открывать: `WPF/AutoServiceExamApp.sln`

SQL: `SQL/01_Create_Database.sql`

База данных: `AutoServiceExam`

Логины:

- admin / admin123
- manager / manager123
- client / client123

Смысл варианта: Автосервис. Можно использовать как тренировочную основу и быстро переделать названия под другую предметную область.
