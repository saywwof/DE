# Минимальные паттерны кода

## DataTable из SQL

```csharp
var table = Database.GetTable("SELECT * FROM Products");
ProductsGrid.ItemsSource = table.DefaultView;
```

## INSERT

```csharp
Database.Execute("INSERT INTO Products(Name, Price) VALUES(@Name, @Price)",
    Database.Param("@Name", name),
    Database.Param("@Price", price));
```

## UPDATE

```csharp
Database.Execute("UPDATE Products SET Name=@Name WHERE Id=@Id",
    Database.Param("@Name", name),
    Database.Param("@Id", id));
```

## DELETE

```csharp
Database.Execute("DELETE FROM Products WHERE Id=@Id", Database.Param("@Id", id));
```

## MessageBox

```csharp
MessageBox.Show("Текст ошибки", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
```
