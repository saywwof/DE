using Microsoft.VisualStudio.TestTools.UnitTesting;
using AutoServiceExamApp.Utils;

namespace AutoServiceExamApp.Tests
{
    [TestClass]
    public class PriceCalculatorTests
    {
        [TestMethod]
        public void ApplyDiscount_1000And15_Returns850()
        {
            decimal result = PriceCalculator.ApplyDiscount(1000m, 15);
            Assert.AreEqual(850m, result);
        }

        [TestMethod]
        public void ApplyDiscount_ZeroDiscount_ReturnsSamePrice()
        {
            decimal result = PriceCalculator.ApplyDiscount(1299m, 0);
            Assert.AreEqual(1299m, result);
        }

        [TestMethod]
        public void ApplyDiscount_NegativePrice_ThrowsException()
        {
            Assert.ThrowsException<System.ArgumentException>(() => PriceCalculator.ApplyDiscount(-1m, 10));
        }
    }
}
