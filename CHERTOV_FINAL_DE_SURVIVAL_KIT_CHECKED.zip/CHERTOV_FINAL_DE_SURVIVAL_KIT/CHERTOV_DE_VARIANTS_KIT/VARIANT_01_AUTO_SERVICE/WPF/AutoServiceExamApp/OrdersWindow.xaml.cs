using System;
using System.Windows;
using AutoServiceExamApp.Data;

namespace AutoServiceExamApp
{
    public partial class OrdersWindow : Window
    {
        public OrdersWindow()
        {
            InitializeComponent();
            LoadOrders();
        }

        private void LoadOrders()
        {
            try
            {
                OrdersGrid.ItemsSource = Database.GetTable(@"
SELECT o.Id, o.OrderDate, o.DeliveryDate, o.Status, o.PickupPoint, u.FullName AS Client,
       SUM(op.Quantity * p.Price * (1 - p.Discount / 100.0)) AS Total
FROM Orders o
LEFT JOIN Users u ON u.Id = o.UserId
LEFT JOIN OrderProducts op ON op.OrderId = o.Id
LEFT JOIN Products p ON p.Id = op.ProductId
GROUP BY o.Id, o.OrderDate, o.DeliveryDate, o.Status, o.PickupPoint, u.FullName
ORDER BY o.Id DESC").DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки заказов.
" + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
