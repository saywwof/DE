using System.Windows;

namespace AutoServiceExamApp
{
    public partial class App : Application
    {
    }
}
