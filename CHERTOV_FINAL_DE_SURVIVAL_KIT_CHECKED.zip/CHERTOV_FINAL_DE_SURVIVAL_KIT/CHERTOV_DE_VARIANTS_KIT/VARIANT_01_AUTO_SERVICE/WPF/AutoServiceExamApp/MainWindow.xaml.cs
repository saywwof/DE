using System;
using System.Data;
using System.Windows;
using AutoServiceExamApp.Data;

namespace AutoServiceExamApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var table = Database.GetTable(
                    "SELECT TOP 1 u.Id, u.FullName, r.Name AS RoleName FROM Users u JOIN Roles r ON r.Id = u.RoleId WHERE u.Login=@Login AND u.Password=@Password",
                    Database.Param("@Login", LoginBox.Text.Trim()),
                    Database.Param("@Password", PasswordBox.Password));

                if (table.Rows.Count == 0)
                {
                    MessageBox.Show("Неверный логин или пароль.", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                DataRow row = table.Rows[0];
                string fullName = row["FullName"].ToString();
                string roleName = row["RoleName"].ToString();
                new ProductsWindow(roleName, fullName).Show();
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось подключиться к базе. Проверь SQL-скрипт и строку подключения.
" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Guest_Click(object sender, RoutedEventArgs e)
        {
            new ProductsWindow("Guest", "Гость").Show();
            Close();
        }
    }
}
