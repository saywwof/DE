# Универсальный магазин

Открывать: `WPF/BlankShopExamApp.sln`

SQL: `SQL/01_Create_Database.sql`

База данных: `BlankShopExam`

Логины:

- admin / admin123
- manager / manager123
- client / client123

Смысл варианта: Универсальный магазин. Можно использовать как тренировочную основу и быстро переделать названия под другую предметную область.
