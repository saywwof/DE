-- Универсальный магазин
-- Выполнить в SQL Server Management Studio.
-- Сервер чаще всего: (localdb)\MSSQLLocalDB

IF DB_ID(N'BlankShopExam') IS NOT NULL
BEGIN
    ALTER DATABASE [BlankShopExam] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE [BlankShopExam];
END
GO

CREATE DATABASE [BlankShopExam];
GO
USE [BlankShopExam];
GO

CREATE TABLE Roles(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE Users(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    RoleId INT NOT NULL,
    Login NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(50) NOT NULL,
    FullName NVARCHAR(150) NOT NULL,
    CONSTRAINT FK_Users_Roles FOREIGN KEY(RoleId) REFERENCES Roles(Id)
);

CREATE TABLE Categories(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Manufacturers(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Suppliers(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Units(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE Products(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL,
    CategoryId INT NOT NULL,
    ManufacturerId INT NOT NULL,
    SupplierId INT NOT NULL,
    UnitId INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL CHECK(Price >= 0),
    StockQuantity INT NOT NULL CHECK(StockQuantity >= 0),
    Discount INT NOT NULL DEFAULT 0 CHECK(Discount BETWEEN 0 AND 100),
    Description NVARCHAR(500) NULL,
    ImagePath NVARCHAR(300) NULL,
    CONSTRAINT FK_Products_Categories FOREIGN KEY(CategoryId) REFERENCES Categories(Id),
    CONSTRAINT FK_Products_Manufacturers FOREIGN KEY(ManufacturerId) REFERENCES Manufacturers(Id),
    CONSTRAINT FK_Products_Suppliers FOREIGN KEY(SupplierId) REFERENCES Suppliers(Id),
    CONSTRAINT FK_Products_Units FOREIGN KEY(UnitId) REFERENCES Units(Id)
);

CREATE TABLE Orders(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    UserId INT NULL,
    OrderDate DATE NOT NULL,
    DeliveryDate DATE NULL,
    Status NVARCHAR(50) NOT NULL,
    PickupPoint NVARCHAR(200) NOT NULL,
    CONSTRAINT FK_Orders_Users FOREIGN KEY(UserId) REFERENCES Users(Id)
);

CREATE TABLE OrderProducts(
    OrderId INT NOT NULL,
    ProductId INT NOT NULL,
    Quantity INT NOT NULL CHECK(Quantity > 0),
    CONSTRAINT PK_OrderProducts PRIMARY KEY(OrderId, ProductId),
    CONSTRAINT FK_OrderProducts_Orders FOREIGN KEY(OrderId) REFERENCES Orders(Id) ON DELETE CASCADE,
    CONSTRAINT FK_OrderProducts_Products FOREIGN KEY(ProductId) REFERENCES Products(Id)
);

INSERT INTO Roles(Name) VALUES (N'Admin'),(N'Manager'),(N'Client');
INSERT INTO Users(RoleId, Login, Password, FullName) VALUES
(1,N'admin',N'admin123',N'Чертов Иван Дмитриевич'),
(2,N'manager',N'manager123',N'Менеджер Демонстрационный'),
(3,N'client',N'client123',N'Клиент Тестовый');

INSERT INTO Categories(Name) VALUES
(N'Категория 1'),
(N'Категория 2'),
(N'Категория 3');

INSERT INTO Manufacturers(Name) VALUES
(N'Производитель 1'),
(N'Производитель 2'),
(N'Производитель 3');

INSERT INTO Suppliers(Name) VALUES
(N'Поставщик 1'),
(N'Поставщик 2'),
(N'Поставщик 3');

INSERT INTO Units(Name) VALUES (N'шт.'),(N'пара'),(N'комплект'),(N'услуга');

INSERT INTO Products(Name, CategoryId, ManufacturerId, SupplierId, UnitId, Price, StockQuantity, Discount, Description, ImagePath) VALUES
(N'Товар пример 1',1,1,1,1,1000,10,0,N'Описание товара',N'picture.png'),
(N'Товар пример 2',2,2,2,1,1500,5,10,N'Описание товара',N'picture.png'),
(N'Товар пример 3',3,3,3,2,2000,0,20,N'Описание товара',N'picture.png');

INSERT INTO Orders(UserId, OrderDate, DeliveryDate, Status, PickupPoint) VALUES
(3, CAST(GETDATE() AS DATE), DATEADD(day, 3, CAST(GETDATE() AS DATE)), N'Новый', N'Пункт выдачи 1'),
(3, DATEADD(day, -2, CAST(GETDATE() AS DATE)), DATEADD(day, 1, CAST(GETDATE() AS DATE)), N'Готов к выдаче', N'Пункт выдачи 2');

INSERT INTO OrderProducts(OrderId, ProductId, Quantity) VALUES
(1, 1, 1),
(1, 2, 1),
(2, 3, 2);

SELECT 'Database created successfully' AS Result;
