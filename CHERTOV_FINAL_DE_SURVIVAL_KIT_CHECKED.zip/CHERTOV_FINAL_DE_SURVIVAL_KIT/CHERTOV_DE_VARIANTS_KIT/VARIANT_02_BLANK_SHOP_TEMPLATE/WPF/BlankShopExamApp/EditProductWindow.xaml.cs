using System;
using System.Data;
using System.Windows;
using BlankShopExamApp.Data;

namespace BlankShopExamApp
{
    public partial class EditProductWindow : Window
    {
        private readonly int? _productId;

        public EditProductWindow(int? productId)
        {
            InitializeComponent();
            _productId = productId;
            LoadDictionaries();
            if (_productId.HasValue) LoadProduct();
            HeaderText.Text = _productId.HasValue ? "Редактирование записи" : "Добавление записи";
        }

        private void LoadDictionaries()
        {
            LoadCombo(CategoryCombo, "SELECT Id, Name FROM Categories ORDER BY Name");
            LoadCombo(ManufacturerCombo, "SELECT Id, Name FROM Manufacturers ORDER BY Name");
            LoadCombo(SupplierCombo, "SELECT Id, Name FROM Suppliers ORDER BY Name");
            LoadCombo(UnitCombo, "SELECT Id, Name FROM Units ORDER BY Name");
        }

        private void LoadCombo(System.Windows.Controls.ComboBox combo, string sql)
        {
            var table = Database.GetTable(sql);
            combo.ItemsSource = table.DefaultView;
            combo.DisplayMemberPath = "Name";
            combo.SelectedValuePath = "Id";
            if (combo.Items.Count > 0) combo.SelectedIndex = 0;
        }

        private void LoadProduct()
        {
            var table = Database.GetTable("SELECT * FROM Products WHERE Id=@Id", Database.Param("@Id", _productId.Value));
            if (table.Rows.Count == 0) return;
            DataRow row = table.Rows[0];
            NameBox.Text = row["Name"].ToString();
            DescriptionBox.Text = row["Description"].ToString();
            CategoryCombo.SelectedValue = row["CategoryId"];
            ManufacturerCombo.SelectedValue = row["ManufacturerId"];
            SupplierCombo.SelectedValue = row["SupplierId"];
            UnitCombo.SelectedValue = row["UnitId"];
            PriceBox.Text = row["Price"].ToString();
            StockBox.Text = row["StockQuantity"].ToString();
            DiscountBox.Text = row["Discount"].ToString();
            ImagePathBox.Text = row["ImagePath"].ToString();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NameBox.Text))
            {
                MessageBox.Show("Введите наименование.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!decimal.TryParse(PriceBox.Text, out decimal price) || price < 0)
            {
                MessageBox.Show("Цена должна быть числом не меньше 0.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!int.TryParse(StockBox.Text, out int stock) || stock < 0)
            {
                MessageBox.Show("Количество должно быть целым числом не меньше 0.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            if (!int.TryParse(DiscountBox.Text, out int discount) || discount < 0 || discount > 100)
            {
                MessageBox.Show("Скидка должна быть от 0 до 100.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (_productId.HasValue)
            {
                Database.Execute(@"UPDATE Products SET Name=@Name, CategoryId=@CategoryId, Description=@Description, ManufacturerId=@ManufacturerId,
SupplierId=@SupplierId, UnitId=@UnitId, Price=@Price, StockQuantity=@Stock, Discount=@Discount, ImagePath=@ImagePath WHERE Id=@Id",
                    Database.Param("@Name", NameBox.Text.Trim()), Database.Param("@CategoryId", CategoryCombo.SelectedValue), Database.Param("@Description", DescriptionBox.Text.Trim()),
                    Database.Param("@ManufacturerId", ManufacturerCombo.SelectedValue), Database.Param("@SupplierId", SupplierCombo.SelectedValue), Database.Param("@UnitId", UnitCombo.SelectedValue),
                    Database.Param("@Price", price), Database.Param("@Stock", stock), Database.Param("@Discount", discount), Database.Param("@ImagePath", ImagePathBox.Text.Trim()), Database.Param("@Id", _productId.Value));
            }
            else
            {
                Database.Execute(@"INSERT INTO Products(Name, CategoryId, Description, ManufacturerId, SupplierId, UnitId, Price, StockQuantity, Discount, ImagePath)
VALUES(@Name,@CategoryId,@Description,@ManufacturerId,@SupplierId,@UnitId,@Price,@Stock,@Discount,@ImagePath)",
                    Database.Param("@Name", NameBox.Text.Trim()), Database.Param("@CategoryId", CategoryCombo.SelectedValue), Database.Param("@Description", DescriptionBox.Text.Trim()),
                    Database.Param("@ManufacturerId", ManufacturerCombo.SelectedValue), Database.Param("@SupplierId", SupplierCombo.SelectedValue), Database.Param("@UnitId", UnitCombo.SelectedValue),
                    Database.Param("@Price", price), Database.Param("@Stock", stock), Database.Param("@Discount", discount), Database.Param("@ImagePath", ImagePathBox.Text.Trim()));
            }

            MessageBox.Show("Данные сохранены.", "Готово", MessageBoxButton.OK, MessageBoxImage.Information);
            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
