using System.Windows;

namespace BlankShopExamApp
{
    public partial class App : Application
    {
    }
}
